from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder.appName("MySparkApp").getOrCreate()

# Load a csv file into a DATAFrame
df = spark.read.csv("temp.csv", header=True, inderSchema = True)

# Perform transformation

# Save the result csv
df.write.csv("output_data.csv", header=True)

# Stop the sparksession
spark.stop()